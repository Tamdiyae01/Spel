﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DimplePopulator : MonoBehaviour
{
    //För att spawna in alla bollar så har vi en referens till spelobjectet "ballPrefab" 
    public GameObject ballPrefab;
    //"dimples" array-en fungerar som en lista som spelet loopar igenom och sätter ut bollarna på rätt dimples 
    private Dimple[] dimples;

    public void Populate()
    {
        //FindObjectsOfType hittar alla dimples som är med i scenen och lägger in dom i array-en dimples
        dimples = FindObjectsOfType<Dimple>();

        for(int i = 0; i < dimples.Length; i++)
        {
            dimples[i].name = "dimples_" + i;

            //Här instantieras alla bollar på varje relevant dimple i Starting. 
            if (dimples[i].type == DimpleType.STARTING)
            {
                //instantiate spawnar en ball component från ballPrefab
                Ball ball = Instantiate(ballPrefab).GetComponent<Ball>();
                //ball.color måste vara samma som dens motsvarande start dimple färg
                ball.color = dimples[i].color;
                ball.tag = dimples[i].tag;
                ball.name = "ball_" + i;
                //här kallas SetDefaultColor koden från Ball scriptet
                ball.SetDefaultColor();
                //genom att referera till currentDimple så vet detta script vilken dimple som bollen just nu är i
                ball.currentDimple = dimples[i];
                //denna funktion flyttar bollens posistion till att den ligger på samma position som dimpeln som den ska vara på.
                ball.gameObject.transform.position = dimples[i].transform.position;
                dimples[i].ToggleOccupied();
            }

            //denna foreach går igenom alla potentialla neighbour dimples och kontrollerar avståndet mellan spelarens boll och dimplarna för att komma fram till
            //om neighbourn är en faktisk granne eller inte beroende på avståndet. 
            foreach (var neighbour in dimples)
            {
                if(neighbour != dimples[i]){
                    if(Vector3.Distance(neighbour.transform.position, dimples[i].transform.position) < 0.5f){
                        dimples[i].neighbours.Add(new Neighbour(neighbour));
                    }
                }
            }
        }
    }
}
