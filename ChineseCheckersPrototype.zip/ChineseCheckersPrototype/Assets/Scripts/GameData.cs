﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//statisk klass, behöver inte initieras i spelet för att den ska kunna anroppas
public static class GameData
{
    //för att spelaren ska kunna savea och ladda om spelet så måste vi ha några statiska värdem som ändras när spelaren sparar sitt spel.
    private static int numberOfPlayers = 2;
    private static int difficulty = 1;
    private static bool loadGameFromSave = false;


    public static int NumberOfPlayers
    {
        get { return numberOfPlayers; }
        set { numberOfPlayers = value; }
    }

        public static int Difficulty
    {
        get { return difficulty; }
        set { difficulty = value; }

    }

        public static bool LoadGameFromSave
    {
        get { return loadGameFromSave; }
        set { loadGameFromSave = value; }


    }

}
