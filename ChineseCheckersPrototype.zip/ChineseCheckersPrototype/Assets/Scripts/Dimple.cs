﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]

//structen nedan innehåller varje dimples grannar, de dimples som angränsar dimplen i fråga. 
public struct Neighbour {
    public Dimple dimple;

    public Neighbour(Dimple dimp){
        dimple = dimp;
    }
}
//Enum scriptet används för att sätta labels på de olika dimple - prefabsen beroende på dess funktion. "STARTING" dimplarna är de som tillhör spelarnas färger och "GENERIC" dimplarna är de neutrala i mitten av brädet.
public enum DimpleType {
    STARTING,
    GENERIC
}

public class Dimple : MonoBehaviour
{
    //Public scriptet nedan ger oss möjligheten att ändra på färgen hos dimple prefabsen. Eftersom scriptet är public så kan färgerna ändras i inspectorn i unity. 
    public Color color = Color.grey;
    //Nedan ges Dimplarna en type från ENUM DimpleType, som bas så blir dom GENERIC
    public DimpleType type = DimpleType.GENERIC;
    //Listan nedan innehåller dimple-grannarna som tas upp i structen högst upp, eftersom varje dimple har minst två grannar så listas dessa upp i Listan "neighbours"
    public List<Neighbour> neighbours;
    //Boolerna nedan are by default false, however it turns to true if the bool is occupied. 
    public bool occupied = false;
    public bool unlocked = false;
    //searched läggs på dimples som har blivigt searched redan. Detta var för att hindra att samma dimple söks igen vilket orsakade stackoverflow. 
    public bool searched = false;

    //En referens görs till GameController scriptet så att Dimple scriptet kan få tillgång till dess funktioner. 
    private GameController controller;


    void Start()
    {
        //Startfunktionen kallar på SetDefaultColor funktionen vilket ger dimplen dess färg när spelet startar. 
        SetDefaultColor();
        controller = FindObjectOfType<GameController>();
    }

    //void OnMouseOver hanterar vad som händer när spelaren håller musen över en dimple som är "Unlocked" efter att de valt en boll. 
    //Om dimplen är unlocked så ändrar den färg till svart för att markera att spelaren kan välja den om dom klickar på dimplen. 
    //Om spelaren trycker ner så utförs MoveBall till den valda dimplen och IsPlayersTurn sätts till False för att visa att det är AIens tur. 
    void OnMouseOver()
    {
        if(unlocked)
        {
            //Debug.Log("Unlocked");
            GetComponent<Renderer>().material.SetColor("_OutlineColor", Color.black);

            if(Input.GetMouseButtonDown(0))
            {
                controller.selectedBall.MoveBall(this);
                controller.isPlayersTurn = false;
            }
        }
    }

    //OnMouseExit körs när spelarens muspekare flyttas från dess mål. 
    void OnMouseExit()
    {
        if(unlocked){
            GetComponent<Renderer>().material.SetColor("_OutlineColor", Color.cyan);
        }
        else{
            SetDefaultColor();
        }
    }

    //funktionen nedan hämtar komponenten "Renderer". Från Renderer så hämtas färgen "Outline color" från materialet. Materialets outline color sätts sedan public "color" som används för dimplarna.
    public void SetDefaultColor()
    {
        GetComponent<Renderer>().material.SetColor("_OutlineColor", color);
    }

    public void ToggleOccupied()
    {
        occupied = !occupied;
    }
}
