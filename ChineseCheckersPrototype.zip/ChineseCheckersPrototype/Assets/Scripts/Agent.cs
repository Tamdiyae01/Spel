﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Agent : MonoBehaviour
{
    [System.Serializable]
    //Move klassen beskriver ett drag hos AI-spelarna
    public class Move
    {
        //Vi skapar en public move konstruktor för att vi ska kunna instantiera objektet utan att behöva ge argument. 
        public Move() { }
        public Move(Ball ball, Dimple fromDimple, Dimple toDimple)
        {
            //"this" refererar till de som hör till det här objektet  
            this.ball = ball;
            this.fromDimple = fromDimple;
            this.toDimple = toDimple;
        }
        //Vi tar upp de variabler som vi behöver i scriptet, nämligen Bollarna och dimplarna.
        public Ball ball;
        public Dimple fromDimple;
        public Dimple toDimple;

        public double score = 0;
    }

    [System.Serializable]
    //boardstate klassen används för att se hur spelbrädet ser ut just nu så att Ai-en kan räkna ut sina moves. 
    public class BoardState
    {
        //listorna med bollar har alla bollar som tillhör Ai-en och spelaren
        public List<Ball> agentBalls = new List<Ball>();
        public List<Ball> opponentBalls = new List<Ball>();

        //nedan följer två listor 
        [SerializeField] public List<Move> agentMoves = new List<Move>();
        [SerializeField] public List<Move> opponentMoves = new List<Move>();
    }

    //agentID markerar vilket nummer som varje Agent har, dessa blir tilldelade i GameController
    public int agentID = 0;

    //Difficulty avgör hur djup minimaxen går 
    public int difficulty = 3;

    [SerializeField] public BoardState currentState = new BoardState();

    public List<Dimple> targetStartingDimples;
    List<Dimple> agentStartingDimples;

    private GameController controller;

    void Start()
    {
        controller = GetComponent<GameController>();

        //beroende på vilket agentID som varje agent har så kontrollerar dom olika startingdimples och därmed olika bollar. 
        agentStartingDimples = controller.GetDimples("agent_" + agentID.ToString());
        currentState.agentBalls = controller.GetBalls("agent_" + agentID.ToString());

        for (int i = 0; i < controller.agents.Count; i++)
        {
            if (agentID != controller.agents[i].agentID)
                currentState.opponentBalls.AddRange(controller.GetBalls("agent_" + i));
        }

        currentState.opponentBalls.AddRange(controller.GetBalls("player"));
    }

    public void PlayMove()
    {
        Move alpha = new Move();
        alpha.score = double.NegativeInfinity;
        Move beta = new Move();
        beta.score = double.PositiveInfinity;

        currentState.agentMoves = GetMoves(currentState.agentBalls);
        currentState.opponentMoves = GetMoves(currentState.opponentBalls);
        Move move = Minimax(currentState, difficulty, alpha, beta, true);
        ApplyMove(move);
    }

    //Ai-en räknar ut dens potentiella moves genom minimax metoden och väljer sedan den som ger den mest score. 
    Move Minimax(BoardState board, int depth, Move alpha, Move beta, bool maximizing)
    {
        Move bestMove = new Move();
        if (depth == 0)
        {
            double score = 0;
            foreach (var m in board.agentMoves)
            {
                if (m.score > score)
                {
                    score = m.score;
                    bestMove = m;
                }
            }
            return bestMove;
        }

        if (maximizing)
        {
            double maxScore = double.NegativeInfinity;
            foreach (var m in board.agentMoves)
            {
                ApplyMove(m);
                //currentState.agentMoves = GetMoves(currentState.agentBalls);

                m.score = Evaluate(currentState);
                Move compareMove = Minimax(currentState, depth - 1, alpha, beta, false);

                UndoMove(m);
                //currentState.agentMoves = GetMoves(currentState.agentBalls);

                if (compareMove.score > maxScore)
                {
                    maxScore = compareMove.score;
                    bestMove = m;
                }

                alpha = bestMove;
                if (beta.score <= alpha.score)
                    break;
            }
            return bestMove;
        }

        if (!maximizing)
        {
            double minScore = double.PositiveInfinity;
            foreach (var m in board.opponentMoves)
            {
                ApplyMove(m);
                //currentState.playerMoves = GetMoves(currentState.playerBalls);

                m.score = Evaluate(currentState);
                Move compareMove = Minimax(currentState, depth - 1, alpha, beta, false);

                UndoMove(m);
                //currentState.playerMoves = GetMoves(currentState.playerBalls);

                if (compareMove.score < minScore)
                {
                    minScore = compareMove.score;
                    bestMove = m;
                }

                beta = bestMove;
                if (beta.score <= alpha.score)
                    break;
            }
            return bestMove;
        }

        return bestMove;
    }


    void ApplyMove(Move move)
    {
        move.ball.MoveBall(move.toDimple);
    }

    void UndoMove(Move move)
    {
        move.ball.MoveBall(move.fromDimple);
    }

    List<Move> GetMoves(List<Ball> balls)
    {
        List<Move> moves = new List<Move>();
        //foreach loopen loopar igenom Ai-ens balls och deras neighbours. För varje dimple som inte är okuperad så skapas en ny potentiel move. 
        //om en dimple är okuperad så körs en findneighboursbyraycast för att hitta dens grannar och ser om Ai-en kan hoppa över den okuperade dimplen till någon
        //annan unlocked dimple. Dessa läggs isåfall till som en ny move. 
        foreach (var b in balls)
        {
            foreach (var n in b.currentDimple.neighbours)
            {
                if (!n.dimple.occupied)
                {
                    Move m = new Move(b, b.currentDimple, n.dimple);
                    moves.Add(m);
                }
                else
                {
                    var list = b.FindNeighboursByRaycast(b.currentDimple, n.dimple);
                    foreach (var d in list)
                    {
                        Move m = new Move(b, b.currentDimple, d);
                        moves.Add(m);
                    }
                }
            }
        }

        return moves;
    }

    //vad evaluate funktionen gör är att beräkna ai-ens distans till dess mål (vilket är spelarens bas) och substraherar det med spelarens distans till sitt mål
    //som ett resultat av en move. Om funktionen returnerar ett positivt nummer så betyder det att en boardstate är mer jymmsamt för Ai-en än det är för spelaren.
    //destu högre nummret returneras som, destu bättre är movet. 
    double Evaluate(BoardState state)
    {
        //
        float agentDistanceToTarget = 0;
        float playerDistanceToTarget = 0;

        //Ai-ens bollar loopas igenom för att ta reda på vilken player dimple som är längst ifrån aiens boll. Ai-en vill ta sig till den som är längst ifrån 
        //för att fylla på den motsatta basen med sina egna bollar. 
        foreach (var ball in state.agentBalls)
        {
            Dimple furthestTargetDimple = targetStartingDimples[0];
            float dst = Vector3.Distance(furthestTargetDimple.transform.position, ball.currentDimple.transform.position);
            foreach (var d in targetStartingDimples)
            {
                Vector3 ftdPos = furthestTargetDimple.transform.position;
                Vector3 cdPos = ball.currentDimple.transform.position;

                if (Vector3.Distance(ftdPos, cdPos) > dst && !d.occupied)
                {
                    furthestTargetDimple = d;
                    dst = Vector3.Distance(ftdPos, cdPos);
                }
            }

            agentDistanceToTarget += dst;
        }

        foreach (var ball in state.opponentBalls)
        {
            Dimple furthestTargetDimple = agentStartingDimples[0];
            float dst = Vector3.Distance(furthestTargetDimple.transform.position, ball.currentDimple.transform.position);
            foreach (var d in agentStartingDimples)
            {
                Vector3 ftdPos = furthestTargetDimple.transform.position;
                Vector3 cdPos = ball.currentDimple.transform.position;

                if (Vector3.Distance(ftdPos, cdPos) > dst && !d.occupied)
                {
                    furthestTargetDimple = d;
                    dst = Vector3.Distance(ftdPos, cdPos);
                }
            }

            playerDistanceToTarget += dst;
        }

        return (agentDistanceToTarget - playerDistanceToTarget);
    }
}
