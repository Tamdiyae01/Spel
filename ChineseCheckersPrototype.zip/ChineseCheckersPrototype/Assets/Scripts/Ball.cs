﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//enumen "SelectionState" kontrollerar 3 lägen som en boll kan ha. None: att den är neutral, Hover: att spelaren håller muspekaren över bollen och Selected: att spelaren har klickat och valt bollen. 
public enum SelectionState {
    NONE,
    HOVER,
    SELECTED
}

public class Ball : MonoBehaviour
{
    //Public funktionen nedan ger en färg till bollarna för att diferentiera vilket lag dom tillhör
    public Color color;
    //Dimple variabeln används för att spelet ska veta vilken dimple som bollen ligger i. 
    public Dimple currentDimple;
    //SelectionState fungerar som en medlemsvariabel för vilken SelectionState som bollen befinner sig i
    public SelectionState state;

    private List<Dimple> jumpDimples = new List<Dimple>();

    // Vi sätter in en direkt referens till GameController scriptet så att scriptet kan använda sig av GameController under spelets gång.
    private GameController controller;

    void Start()
    {
        controller = FindObjectOfType<GameController>();
        
    }


    void Update()
    {
        //switch satsen ändrar bollarnas färg beroende på deras SelectionState. 
        switch(state)
        {
            case SelectionState.HOVER:
                GetComponent<Renderer>().material.SetColor("_OutlineColor", Color.cyan);
                break;
            case SelectionState.SELECTED:
                GetComponent<Renderer>().material.SetColor("_OutlineColor", Color.cyan);
                break;
            default:
                GetComponent<Renderer>().material.SetColor("_OutlineColor", Color.black);
                break;
        }
    }

    //Den här funktionen kontrollerar bollarnas SelectionState genom OnMouseOver.  
    //OnMouseOver kontrollerar om spelaren håller musen över en boll, om spelaren gör det så ändrar den bollens state till "HOVER". 
    //If satsen nedanför kontrollerar om spelaren has klickat på en boll, bollen som har blivit klickat på får då selection staten "SELECTED"
    void OnMouseOver()
    {
        if(state != SelectionState.SELECTED && controller.selectedBall == null && gameObject.tag == "player"){
            state = SelectionState.HOVER;
        }

        
        if(Input.GetMouseButtonDown(0) && state != SelectionState.SELECTED && controller.selectedBall == null && gameObject.tag == "player")
        {
            state = SelectionState.SELECTED;
            controller.selectedBall = this;
            UnlockReachableDimples();
        }
    }

    //OnMouseExit kontrollerar om bollarna inte har SelectedState som "Selected", bollen får då staten "None"
    void OnMouseExit()
    {
        if(state != SelectionState.SELECTED){
            state = SelectionState.NONE;
        }
    }


    private void UnlockReachableDimples()
    {
        //denna foreach går igenom alla dimples från Neighbours listan i dimple scriptet för att se vilka dimples som spelarens valda boll kan hoppa till.
        //om den valda dimplen inte har labeln "occupied" så ändrar den färg för att markera att den är tillgänglig till att flytta till. 
        //om dimplen är okkuperad av en boll så går else satsen igenom och kollar om det finns dimples som går att hoppa till runt om den okuperade dimplen. 
        foreach (var n in currentDimple.neighbours)
        {
            if(!n.dimple.occupied)
            {
                n.dimple.GetComponent<Renderer>().material.SetColor("_OutlineColor", Color.cyan);
                n.dimple.unlocked = true;
            }
            else
            {
                jumpDimples.AddRange(FindNeighboursByRaycast(currentDimple, n.dimple));

                if(jumpDimples.Count > 0){
                    foreach (var j in jumpDimples)
                    {
                        j.unlocked = true;
                        j.GetComponent<Renderer>().material.SetColor("_OutlineColor", Color.cyan);
                    }
                }
            }
        }
    }

    //funktionen nedan hämtar komponenten "Renderer". Från Renderer så hämtas färgen "Outline color" från materialet. Materialets outline color sätts sedan public "color" som används för dimplarna.
    public void SetDefaultColor()
    {
        GetComponent<Renderer>().material.color = color;
    }

    //Denna funktion hanterar när spelaren flyttar på en av sina bollar.
    public void MoveBall(Dimple d)
    {
        currentDimple.SetDefaultColor();
        //när spelaren har flyttat på sin boll så låses dom "unlocked" dimples igen för att det inte längre är spelarens tur. 
        currentDimple.unlocked = false;
        currentDimple.searched = false;
        d.SetDefaultColor();
        d.unlocked = false;
        d.searched = false;

        //Foreach loopen går igenom de dimples som spelaren kan hoppa till och ändrar deras färg till default color
        foreach (var n in currentDimple.neighbours)
        {
            n.dimple.SetDefaultColor();
            n.dimple.unlocked = false;
        }

        if(jumpDimples.Count > 0)
        {
            foreach (var j in jumpDimples)
            {
                j.SetDefaultColor();
                j.unlocked = false;
                j.searched = false;
            }

            jumpDimples.Clear();
        }
        //Här togglas occupied labeln för dimpeln som bollen flyttas från eftersom den nu blir fri.
        currentDimple.ToggleOccupied();
        //Här togglas occupied labeln för dimpeln som bollen flyttas till eftersom den nu blir occupied
        d.ToggleOccupied();
        //När bollen flyttas så blir en ny dimple "d"
        currentDimple = d;

        //här flyttas bollen till den nya dimpeln. 
        transform.position = currentDimple.transform.position;
        //när spelaren har flyttat sin boll så ändras bollens SelectionState tillbaka till None.
        state = SelectionState.NONE;

        FindObjectOfType<GameController>().selectedBall = null;
    }

    //En raycast skickas ut för att hitta spelarens grannar från listan med dimples. Om en neighbour är okuperad så skickas en ny raycast ut med större range
    //för att se om spelaren kan hoppa över den okuperade till en ookuperad dimple. 
    public List<Dimple> FindNeighboursByRaycast(Dimple startDimple, Dimple endDimple)
    {
        List<Dimple> jDimplesToReturn = new List<Dimple>();

        RaycastHit[] hits;
        hits = Physics.RaycastAll(startDimple.transform.position, endDimple.transform.position - startDimple.transform.position, 1.0f);
        Debug.DrawRay(startDimple.transform.position, (endDimple.transform.position- startDimple.transform.position) * 1.0f, Color.red, 2.0f, false);

        foreach (var hit in hits)
        {
            Dimple dHit = hit.transform.gameObject.GetComponent<Dimple>();
            if(dHit != null){                
                if(!dHit.occupied && !dHit.searched){
                    jDimplesToReturn.Add(dHit);
                    dHit.searched = true;

                    foreach (var n in dHit.neighbours)
                    {
                        if(n.dimple.occupied)
                        {
                            List<Dimple> newSearch = FindNeighboursByRaycast(dHit, n.dimple);
                            if(newSearch.Count > 0)
                                jDimplesToReturn.AddRange(newSearch);
                        }                     
                    }
                }
            }
        }
        foreach (var hit in hits)
        {
            if (hit.transform.gameObject.GetComponent<Dimple>() != null)
                hit.transform.gameObject.GetComponent<Dimple>().searched = false;
        }

        return jDimplesToReturn;
    }
}
