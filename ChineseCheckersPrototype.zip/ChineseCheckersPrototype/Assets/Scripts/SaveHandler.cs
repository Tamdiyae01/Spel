﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SaveHandler : MonoBehaviour
{
    public static void SaveGame()
    {
        Ball[] balls = FindObjectsOfType<Ball>();
        foreach (var b in balls)
            PlayerPrefs.SetString(b.name, b.currentDimple.name);

        PlayerPrefs.SetInt("NumberOfPlayers", GameData.NumberOfPlayers);
        PlayerPrefs.SetInt("Difficulty", GameData.Difficulty);
        PlayerPrefs.SetInt("SavedGame", 1);
    }

    public static void LoadGameFromSave()
    {
        Ball[] balls = FindObjectsOfType<Ball>();
        Dimple[] dimples = FindObjectsOfType<Dimple>();

        foreach (var b in balls)
        {
            if (PlayerPrefs.HasKey(b.name))
            {
                string dimpleName = PlayerPrefs.GetString(b.name);
                foreach (var d in dimples)
                {
                    if(d.name == dimpleName)
                        b.MoveBall(d);
                }
            }
        }
    }
}
