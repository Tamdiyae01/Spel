﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

//Menuhandler scriptet hanterar spelets meny genom ett kanvas spelobjekt. Kanvasens knappar är kopplade till funktionerna nedan. 
public class MenuHandler : MonoBehaviour
{
    [Header("Dropdowns")]
    public TMP_Dropdown players;

    public TMP_Dropdown difficulty;

    [Header("Buttons")]

    public Button loadGame;

    private void Start()
    {
        
        if (PlayerPrefs.HasKey("SavedGame"))
        {
            if (PlayerPrefs.GetInt("SavedGame") == 0)
            {
                loadGame.interactable = false;
            }
            else
                loadGame.interactable = true;

        }

            else
            {
                PlayerPrefs.SetInt("SavedGame", 0);
                loadGame.interactable = false;
            }
    }


    public void NewGame()
    {
        GameData.NumberOfPlayers = players.value + 2;
        GameData.Difficulty = difficulty.value + 1;
        GameData.LoadGameFromSave = false;

        SceneManager.LoadScene("Prototype");
    }

    public void LoadGame()
    {
        GameData.NumberOfPlayers = PlayerPrefs.GetInt("NumberOfPlayers");
        GameData.Difficulty = PlayerPrefs.GetInt("Difficulty");
        GameData.LoadGameFromSave = true;

        SceneManager.LoadScene("Prototype");
    }

    public void Quit()
    {
        Application.Quit();
    }
}

