﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    [Header("Game Settings")]
    //Rangen nedan betyder hur många spelare som kan vara i en match, rangen sattes till 2-6, med 2 som standardvärde.
    [Range(2,6)]
    public int numberOfPlayers = 2;
    //Difficulty är en annan range som sattes till 1-5, med 1 som standardvärde. 
    [Range(1,5)]
    public int difficulty = 1;

    private Ball[] balls;
    private Dimple[] dimples;
    //selectedBall är bollen som spelaren har valt för tillfället.
    [HideInInspector] public Ball selectedBall;
    //dimplepopulator är en referens till scriptet "DimplePopulator" så att detta script kan kalla på "DimplePopulator scriptet i start funktionen
    private DimplePopulator dimplePopulator;

    [HideInInspector] public List<Agent> agents = new List<Agent>();

    //isPlayersTurn är en bool som hanterar om det är spelarens tur eller inte. 
    [HideInInspector] public bool isPlayersTurn = true;

    void Start()
    {
        //När GameController scriptet startas så kallas "DimplePopulator" scriptet och kör "populate" funktionen
        dimplePopulator = GetComponent<DimplePopulator>();
        dimplePopulator.Populate();


        numberOfPlayers = GameData.NumberOfPlayers;
        difficulty = GameData.Difficulty;

        balls = FindObjectsOfType<Ball>();
        dimples = FindObjectsOfType<Dimple>();

        //for funktionen nedan går igenom antalet players som spelaren har valt och ger Ai-en svårigheten som spelaren har valt.
        //för varje antal spelare som spelaren har valt så skapas en ny "agent" som styrs av "Agent" scriptet.
        for(int i = 0; i < numberOfPlayers - 1; i++)
        {
            Agent agent = gameObject.AddComponent<Agent>();
            agent.agentID = i;
            agent.difficulty = difficulty;

            switch(i)
            {
                case 0: agent.targetStartingDimples = GetDimples("player"); break;
                case 1: agent.targetStartingDimples = GetDimples("agent_3"); break;
                case 2: agent.targetStartingDimples = GetDimples("agent_4"); break;
                case 3: agent.targetStartingDimples = GetDimples("agent_1"); break;
                case 4: agent.targetStartingDimples = GetDimples("agent_2"); break;

            }

            agents.Add(agent);
        }

        if (GameData.LoadGameFromSave)
            SaveHandler.LoadGameFromSave();

    }

    void Update()
    {
        //om det inte är spelarens tur så spelar agenterna sina turer och "isPlayersTurn" ändras till true för att visa att det nu är spelarens tur.
        if(!isPlayersTurn)
        {
            foreach (var agent in agents)
                agent.PlayMove();

            isPlayersTurn = true;
        }
        
       
        if(AgentWinCheck())
        {
            //do this
        }

        if (PlayerWinCheck())
        {
            //do that
        }
    }

    private bool AgentWinCheck()
    {
        foreach (var agent in agents)
        {
            foreach (var targetDimple in agent.targetStartingDimples)
            {
                if(targetDimple.occupied )
                {
                    foreach (var b in agent.currentState.agentBalls)
                    {
                        if (b.currentDimple != targetDimple)
                            return false;
                    }
                }
                
                else
                {
                    return false;
                }

            }
        }

        return true;
    }

    private bool PlayerWinCheck()
    {
       foreach (var targetDimple in agents[0].targetStartingDimples)
        {
            if (targetDimple.occupied)
            {
                foreach (var b in GetBalls("player"))
                {
                    if (b.currentDimple != targetDimple)
                        return false;
                }
            }

            else
            {
                return false;
            }
        }
        return true;
    }
    public void SaveAndQuit()
    {
        SaveHandler.SaveGame();
        SceneManager.LoadScene("Main Menu");
    }

    public List<Ball> GetBalls(string tag)
    {
        List<Ball> ballList = new List<Ball>();
        foreach (var b in FindObjectsOfType<Ball>())
        {
            if(b.gameObject.transform.tag == tag)
                ballList.Add(b);
        }

        return ballList;
    }

    public List<Dimple> GetDimples(string tag)
    {
        List<Dimple> dimpleList = new List<Dimple>();
        foreach (var d in FindObjectsOfType<Dimple>())
        {
            if(d.gameObject.transform.tag == tag)
                dimpleList.Add(d);
        }

        return dimpleList;
    }
}
